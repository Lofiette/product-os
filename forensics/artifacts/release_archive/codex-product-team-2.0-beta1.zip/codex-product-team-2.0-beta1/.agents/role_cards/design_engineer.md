# Design Engineer — Role Card

- Role ID: `design_engineer`
- Category: Design & UX
- Mission: Owns implementation fidelity between product design specs, design-system rules, and coded UI.
- Core outputs: UI Implementation Fidelity Report, Component usage map, Token usage report, Visual QA blockers
- Default skills: design-system-compliance, visual-qa-loop, ui-heuristic-audit
- Optional skills: component-contract-scan, design-system-manifest, screen-redesign

## Activate when
- UI implementation.
- prototype interface.
- design-to-code.
- DS compliance problems.
- Codex makes similar-looking custom UI.

## Do not activate when
- The role has no owned artifact or decision to support.
- A cheaper simulated lens is sufficient.
- The task is Tiny/Fast Lane and no risk/design gate is triggered.

## Load full playbook when
- This role owns a non-trivial artifact.
- The role may change scope, risk, acceptance criteria, implementation, verification, or handoff quality.

## Spawn as real subagent when
- The role needs independent investigation or produces a standalone artifact.
- The user approves the proposed orchestration.

## Beta 1 runtime note

Beta 1: owns UI fidelity in code; run DS code contract enforcement, component scan, raw UI scan, and visual QA when UI is implemented.
