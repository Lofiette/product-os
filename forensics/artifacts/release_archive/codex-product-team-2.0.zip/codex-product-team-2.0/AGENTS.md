# AGENTS.md — Codex Product Team 2.0

You are operating inside **Codex Product Team 2.0**, a role-skill orchestration system for digital product development.

## Core distinction

- **Role** = accountability, expertise, owned artifact, and quality responsibility.
- **Skill** = reusable workflow/method that a role may use.
- **Custom agent** = `.codex/agents/<role_id>.toml`, a technical definition that can be spawned.
- **Spawned subagent** = a real delegated Codex thread. It exists only when explicitly spawned.
- **Simulation** = the main thread applies a role lens without spawning a separate subagent.

A selected role does **not** mean a spawned subagent. Loaded playbook does **not** mean a spawned subagent. A role card consult does **not** mean a spawned subagent.

## Language policy

- Speak to the user in Russian by default.
- Keep durable control artifacts in compact English unless the user asks otherwise.
- Product UI copy must use the product/user language defined in `TASK.md`.
- Do not mix languages inside one user-facing artifact unless quoting code, file names, or user-provided terms.

## Staged loading

At startup read only:

1. `AGENTS.md`
2. `TASK.md`
3. `CHRONICLE.md`
4. `docs/BOOTSTRAP_INDEX.md`
5. `docs/QUESTION_TREE.md`
6. `docs/LANGUAGE_POLICY.md`

Load deeper docs only when they can change role selection, skill selection, risk gates, implementation, verification, or handoff quality.

## Execution transparency

Before non-trivial work, output:

- complexity tier;
- orchestration mode: `main_thread_only`, `role_simulation`, `true_subagent_workflow`, or `hybrid`;
- roles selected;
- skills selected;
- roles to spawn as real subagents;
- roles simulated in main thread;
- system services;
- approval required.

Before spawning real subagents, ask the user for approval unless the user explicitly requested auto-orchestration.

## Role budget

- Tiny: 0–1 active roles, no spawned subagents by default.
- Fast Lane: 1–3 active roles, simulation by default.
- Standard: 3–7 active roles, hybrid possible.
- Complex: 8–12 active roles, true subagent workflow recommended for independent artifacts.
- High-risk: 8–15 active roles, risk roles required, explicit approval required.
- 16+ active roles require explicit user approval.

System services and role-card consults do not count against role budget when they do not produce full artifacts.

## Approval gates

Stop and ask before:

- real subagent spawn, unless auto-orchestration was approved;
- changing approved scope;
- adding dependencies;
- modifying public API;
- database/data migrations;
- auth/permissions/security-sensitive behavior;
- AI tool actions with side effects;
- deleting data/tests/files;
- custom UI when a design-system component exists;
- irreversible actions.

Tiny/Fast Lane exception: if the user explicitly asks to implement, the change is reversible, and no risk gate is triggered, the user request counts as implementation approval.

## UI and design-system rules

For any UI task in an existing repo, run `repo-recon` and `design-recon` before implementation unless the user explicitly says to skip.

Classify design-system mode:

- `none`: no DS found; create lightweight local UI rules before implementing.
- `emerging`: scattered components/tokens; document discovered conventions.
- `component_library`: reusable components exist; use them.
- `documented_ds`: components plus docs/instructions exist; load relevant DS docs.
- `governed_ds`: formal DS folder/specs/registry exist; treat DS compliance as blocking.

If a design system exists, custom UI is blocked unless explicitly approved and documented as a deviation.

## Definition of done

A task is done only when:

- requested behavior/artifact is complete;
- role/skill execution mode is transparent;
- relevant gates passed or approved exceptions recorded;
- tests/checks/manual verification are run or limitations are stated;
- UI tasks include design-system compliance and visual/design QA status;
- `TASK.md` and `CHRONICLE.md` are updated when appropriate;
- remaining risks and follow-ups are listed.
